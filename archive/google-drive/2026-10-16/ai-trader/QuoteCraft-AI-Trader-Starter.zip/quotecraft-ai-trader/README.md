# QuoteCraft AI Trader — practice prototype

Open `index.html` in a browser. No installation, server, API key, or account required.

This is an initial **paper-only** simulator with manually entered CAD-denominated observed prices, simulated trades, local browser storage, an exportable JSON backup, and a basic five-observation momentum rule. It is **not** AI, live market monitoring, predictive modeling, or broker trading yet. No actual orders can be placed.

Future phases: validated market data source; historical backtesting with transaction costs; model evaluation on unseen data; persistent backend alerts; brokerage-specific API research and explicit authorization controls. Never commit credentials to GitHub. For private use, create a private repository.

The browser's local storage can be cleared, so export backups periodically. Do not enter private brokerage credentials in this prototype.
